﻿using Syncfusion.Pdf.Graphics;
using Syncfusion.Pdf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoardingPassProject.Model;
using Syncfusion.Drawing;
using Syncfusion.Pdf.Barcode;
using Syncfusion.Pdf.Interactive;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection.Metadata;
using System.Xml.Linq;

namespace BoardingPassProject
{
    internal class BoardingPassDocument
    {
        BoardingPassModel model;
        PdfPage currentPage;
        FileStream headerfontStream = new FileStream(@"../../../Assets/OpenSans-ExtraBold.ttf", FileMode.Open, FileAccess.Read);
        public BoardingPassDocument(BoardingPassModel model)
        {
            this.model = model;
        }

        public void GeneratePdf(Stream stream)
        {
            PdfDocument document = new PdfDocument();
            document.PageSettings.Orientation = PdfPageOrientation.Landscape;
            document.PageSettings.Size = new SizeF(700, 288);
            document.PageSettings.Margins.All = 0;
            currentPage = document.Pages.Add();
            PdfLayoutResult result;

            //Left Side Boarding Pass
            RectangleF rectangle = new RectangleF(0,0,700,38);
            currentPage.Graphics.DrawRectangle(PdfBrushes.DarkBlue, rectangle);
            PdfFont titleFont = new PdfTrueTypeFont(headerfontStream, 15);
            PdfStringFormat stringFormat = new PdfStringFormat();
            stringFormat.Alignment = PdfTextAlignment.Right;
            currentPage.Graphics.DrawString("BOARDING PASS", titleFont, PdfBrushes.White, new PointF(500-20, 8), stringFormat);
            float y = rectangle.Height + 20;

            //Airlines
            RectangleF rect = new RectangleF(0, 0, 64, 288);
            currentPage.Graphics.DrawRectangle(PdfBrushes.Red, rect);
            PdfFont leftFont = new PdfTrueTypeFont(headerfontStream, 15);
            PdfStringFormat format = new PdfStringFormat();
            stringFormat.Alignment = PdfTextAlignment.Center;
            currentPage.Graphics.RotateTransform(270);
            currentPage.Graphics.DrawString("Your Airlines", leftFont, PdfBrushes.White, new Point(0,(int)y+120), format);
            currentPage.Graphics.RotateTransform(-270);
            float x = rect.Width + 25;

            result = FormDetails(x,y);
            
            document.Save(stream);
            document.Close(true);
            
        }
        public PdfLayoutResult FormDetails(float x, float y)
        {
            FileStream titlefontStream=new FileStream(@"../../../Assets/OpenSans-Light.ttf", FileMode.Open, FileAccess.Read);
            PdfFont titleFont = new PdfTrueTypeFont(titlefontStream, 12);
            
            FileStream contentfontStream = new FileStream(@"../../../Assets/OpenSans-Bold.ttf", FileMode.Open, FileAccess.Read);
            PdfFont contentFont = new PdfTrueTypeFont(contentfontStream, 12);

            //Left side:
            //Passenger Name
            currentPage.Graphics.DrawString("Passenger Name", titleFont, PdfBrushes.Black, new PointF(x , y ));
            var passengerName = new PdfTextElement($" {model.PassengerName}", contentFont);
            var result = passengerName.Draw(currentPage, new PointF(x, y + 20));

            //From
            currentPage.Graphics.DrawString("From", titleFont, PdfBrushes.Black, new PointF(x , y + 50));
            var from = new PdfTextElement($" {model.From}", contentFont);
            result = from.Draw(currentPage, new PointF(x, y + 70));

            FileStream ChgeStream = new FileStream(@"../../../Assets/OpenSans-Bold.ttf", FileMode.Open, FileAccess.Read);
            PdfFont ChangepdfFont = new PdfTrueTypeFont(ChgeStream, 18);

            //Flight
            currentPage.Graphics.DrawString("Flight", titleFont, PdfBrushes.Black, new PointF(x + 150, y + 50));
            var flight = new PdfTextElement($"{model.Flight}", ChangepdfFont);
            result = flight.Draw(currentPage, new PointF(x + 150, y + 70));
            float barcodeStartPoint =result.Bounds.X;

            //Date
            currentPage.Graphics.DrawString("Date", titleFont, PdfBrushes.Black, new PointF(x + 250, y + 50));
            var date = new PdfTextElement($"{model.Date}", ChangepdfFont);
            result = date.Draw(currentPage, new PointF(x + 250, y + 70));
            //float barcodeEndPoint=result.Bounds.Bottom;

            //To
            currentPage.Graphics.DrawString("To", titleFont, PdfBrushes.Black, new PointF(x, y + 100));
            var destination = new PdfTextElement($"{model.To}", contentFont);
            result = destination.Draw(currentPage, new PointF(x, y + 120));

            ////Time
            currentPage.Graphics.DrawString("Time", titleFont, PdfBrushes.Black, new PointF(x + 250, y + 100));
            var time = new PdfTextElement($"{model.Time}", ChangepdfFont, PdfBrushes.Red);
            result = time.Draw(currentPage, new PointF(x + 250, y + 120));

            //Gate
            currentPage.Graphics.DrawString("Gate", titleFont, PdfBrushes.Black, new PointF(x, y + 150));
            var gate = new PdfTextElement($"{model.Gate}", ChangepdfFont);
            result = gate.Draw(currentPage, new PointF(x, y + 170));

            //Seat
            currentPage.Graphics.DrawString("Seat", titleFont, PdfBrushes.Black, new PointF(x + 50, y + 150));
            var seat = new PdfTextElement($"{model.Seat}", ChangepdfFont);
            result = seat.Draw(currentPage, new PointF(x + 50, y + 170));

            FileStream FooterStream = new FileStream(@"../../../Assets/Open Sans Light.ttf", FileMode.Open, FileAccess.Read);
            PdfFont footerFont = new PdfTrueTypeFont(FooterStream, 8);
            var footerText = new PdfTextElement("*Gate Closes 30 Minutes Before Departure", footerFont, PdfBrushes.Red);
            result = footerText.Draw(currentPage, new Point((int)x, (int)y+200));

            //Barcode
            PdfCode39Barcode barcode = new PdfCode39Barcode();
            barcode.BarHeight = 30;
            barcode.Text = "CODE39$";
            barcode.TextDisplayLocation = TextLocation.None;
            barcode.Draw(currentPage, new PointF(barcodeStartPoint, y+160));

            //DashLine
            var pen = new PdfPen(Color.Gray, 1);
            pen.DashStyle = PdfDashStyle.Dash;
            pen.DashOffset = 0.5f;
            currentPage.Graphics.DrawLine(pen, 500, 500, 500, 20);


            //Right side Boarding Pass:
            PdfFont titlFt = new PdfTrueTypeFont(headerfontStream, 15);
            currentPage.Graphics.DrawString("BOARDING PASS", titlFt, PdfBrushes.White, new PointF(500+30 , 8));

            //PassengerName
            currentPage.Graphics.DrawString("Passenger Name", titleFont, PdfBrushes.Black, new PointF(500 + 20, y));
            var passengerNme = new PdfTextElement($" {model.PassengerName}", contentFont);
            result = passengerNme.Draw(currentPage, new PointF(500 + 20, y + 20));

            //From
            currentPage.Graphics.DrawString("From", titleFont, PdfBrushes.Black, new PointF(500 + 20, y + 50));
            var RightFrom = new PdfTextElement($" {model.From}", contentFont);
            result = RightFrom.Draw(currentPage, new PointF(500 + 20, y + 70));

            //To
            currentPage.Graphics.DrawString("To", titleFont, PdfBrushes.Black, new PointF(500 + 20, y + 95));
            var to = new PdfTextElement($"{model.To}", contentFont);
            result = to.Draw(currentPage, new PointF(500 + 20, y + 115));

            //Flight
            currentPage.Graphics.DrawString("Flight", titleFont, PdfBrushes.Black, new PointF(500 + 20, y + 140));
            var flght = new PdfTextElement($"{model.Flight}", contentFont);
            result = flght.Draw(currentPage, new PointF(500 + 20, y + 160));

            //Date
            currentPage.Graphics.DrawString("Date", titleFont, PdfBrushes.Black, new PointF(500+100, y + 140));
            var dt = new PdfTextElement($"{model.Date}", contentFont);
            result = dt.Draw(currentPage, new PointF(500+100, y + 160));

            //Gate
            currentPage.Graphics.DrawString("Gate", titleFont, PdfBrushes.Black, new PointF(500+20, y + 180));
            var gt = new PdfTextElement($"{model.Gate}", contentFont);
            result = gt.Draw(currentPage, new PointF(500 +20, y + 200));

            //Seat
            currentPage.Graphics.DrawString("Seat", titleFont, PdfBrushes.Black, new PointF(500 + 52, y + 180));
            var st = new PdfTextElement($"{model.Seat}", contentFont);
            result = st.Draw(currentPage, new PointF(500 + 52, y + 200));

            //Time
            currentPage.Graphics.DrawString("Time", titleFont, PdfBrushes.Black, new PointF(500 + 100, y + 180));
            var tm = new PdfTextElement($"{model.Time}", contentFont);
            result = tm.Draw(currentPage, new PointF(500 + 100, y + 200));

            return result;
            
        }
    }
}
